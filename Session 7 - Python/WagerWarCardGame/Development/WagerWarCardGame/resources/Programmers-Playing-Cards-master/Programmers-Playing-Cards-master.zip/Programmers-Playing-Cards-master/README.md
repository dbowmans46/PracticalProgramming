# Programmers-Playing-Cards
Play cards with style with this fancy programmer’s deck. 52 languages! The perfect deck of cards to show your passion in programming!


### The Story

Let me run you through a short scenario: 

*Your programmer friends are coming to play poker, and after everyone grabs a beer and sits down, you distribute the cards for the first round. But... to everyone's surprise, they see a different programming language on every card, and laugh. Next thing you know, this becomes so intriguing that the game is paused while you look at every card, one by one. And hey, what do you know, you could even learn a few more languages!*

#### [Check out our website!!](http://coderlife.io)


### [Languages Included](https://github.com/Bathlamos/Programmers-Playing-Cards/wiki)

### Mockups of the cards

<img src="http://legault.cc/data/Jokers.png?rdn=0054">
<img src="http://legault.cc/data/Hearts.png?rdn=0054"">
<img src="http://legault.cc/data/Spades.png?rdn=0054"">
<img src="http://legault.cc/data/Diamonds.png?rdn=0054"">
<img src="http://legault.cc/data/Clubs.png?rdn=0054"">

### Do you want to know more about this project, or get a deck of cards?

### [Check out our website!!](http://coderlife.io)
