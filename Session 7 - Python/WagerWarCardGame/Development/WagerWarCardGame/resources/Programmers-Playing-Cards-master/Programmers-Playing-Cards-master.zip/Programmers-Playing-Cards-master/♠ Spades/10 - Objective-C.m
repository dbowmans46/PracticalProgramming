Rank *rank = [Rank 
  rankWithValue:10];
Suit *suit = [Suit 
  suitWithName:@"spades"]
Card *card = [
  [Card alloc] 
  initWithRank:rank 
  suit:suit];
