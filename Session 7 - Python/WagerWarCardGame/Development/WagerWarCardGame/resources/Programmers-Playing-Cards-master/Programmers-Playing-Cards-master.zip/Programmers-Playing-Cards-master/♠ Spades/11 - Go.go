type Card struct {
  rank int
  name string
  suit string
}

c := Card{11, "Jack", "spades"}
