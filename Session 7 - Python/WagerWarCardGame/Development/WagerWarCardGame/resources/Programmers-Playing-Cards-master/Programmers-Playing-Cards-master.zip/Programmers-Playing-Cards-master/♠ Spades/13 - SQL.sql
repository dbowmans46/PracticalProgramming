SELECT card FROM deck
  WHERE rank=13
  AND suit="spades"
  AND name="king";