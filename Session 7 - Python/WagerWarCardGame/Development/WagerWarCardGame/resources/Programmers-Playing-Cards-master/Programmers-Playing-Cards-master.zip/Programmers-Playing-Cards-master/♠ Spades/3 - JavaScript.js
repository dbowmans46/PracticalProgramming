var card = {
  rank: 3,
  suit: "spades"
};
console.log(
  JSON.stringify(card));
