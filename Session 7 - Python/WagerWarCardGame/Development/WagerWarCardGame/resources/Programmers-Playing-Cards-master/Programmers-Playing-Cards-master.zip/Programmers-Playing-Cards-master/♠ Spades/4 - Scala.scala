case class Card(
  rank: Int, 
  suit: String
)
val c = Card(4, "spades")
