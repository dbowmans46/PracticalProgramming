type card = { 
  Rank : byte;
  Suit : string }

let card = { 
  Rank = 7; 
  Suit = "spades" }
