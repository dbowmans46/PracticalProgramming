struct Card {
  var rank: UInt8
  var suit: Suit
}

let card = Card(
  rank: 10, 
  suit: .Clubs)
