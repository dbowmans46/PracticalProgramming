var card = new {
	rank = 11,
	name = "Jack",
	suit = "clubs"
};
Console.WriteLine(card);