type suit = Hearts | Spades | Clubs | Diamonds
type card = { rank : int; suit : suit; }

let card = {
  rank = 3;
  suit = Clubs;
}