struct card {
  const int rank;
  const char* suit;
} card = {
  7, 
  "clubs"
};
