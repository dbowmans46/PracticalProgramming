function card(
      [int] $rank, 
      [string] $suit) {
  Wscript.Echo rank
  Wscript.Echo suit
}
card(10, "hearts")
