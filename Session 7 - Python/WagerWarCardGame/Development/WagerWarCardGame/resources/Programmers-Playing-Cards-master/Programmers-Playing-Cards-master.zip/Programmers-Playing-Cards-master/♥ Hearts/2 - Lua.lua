Card = {
  rank = 2,
  suit = "hearts",
  print = function (self)
    print rank..suit
  end
}
