data Card = Card { 
  rank :: Int, 
  suit :: String }
  deriving (Show)

card = Card { rank = 4, 
  suit = "Hearts" }
