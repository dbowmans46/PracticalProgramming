my $card = { 
  rank => 7, 
  suit => "hearts"
}

print "$card{$rank} of 
         $card{$suit}"
