class < Card
  def initialize
    @name = 'Jack'
    @value = 11
    @suit = 'diamonds'
  end
end
