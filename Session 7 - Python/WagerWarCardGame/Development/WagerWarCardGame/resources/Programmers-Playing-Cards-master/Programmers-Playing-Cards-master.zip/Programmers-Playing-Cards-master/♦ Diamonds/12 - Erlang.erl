Card = #{
  rank => 12,
  name => "Queen",
  suit => "diamonds"},

io:fwrite("~15p~n", 
          [Card]),
