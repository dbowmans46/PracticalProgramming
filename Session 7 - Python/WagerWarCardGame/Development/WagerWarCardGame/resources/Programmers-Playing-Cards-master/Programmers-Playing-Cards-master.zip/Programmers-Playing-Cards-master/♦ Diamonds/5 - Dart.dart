var card = { 
  'rank': 5, 
  'suit': 'diamonds' 
};

print(card);
