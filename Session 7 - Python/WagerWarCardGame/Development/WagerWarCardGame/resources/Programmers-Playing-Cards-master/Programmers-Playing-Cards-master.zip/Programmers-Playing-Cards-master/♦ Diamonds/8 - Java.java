import deck.Suit;

public class Card {
  int rank = 8;
  Suit suit = 
       Suit.DIAMONDS;
}
